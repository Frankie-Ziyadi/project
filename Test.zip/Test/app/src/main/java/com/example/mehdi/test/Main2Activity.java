package com.example.mehdi.test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

    }
    public void onClick(View v)
    {
        Intent i =  new Intent(Main2Activity.this,MainActivity.class);

        switch(v.getId())
        {
            case R.id.B_hopistals:
                i.putExtra("value","Hospital");
                startActivity(i);
                break;
            case R.id.B_schools:
                i.putExtra("value","School");
                startActivity(i);
                break;
            case R.id.B_restaurants:
                i.putExtra("value","Restaurant");
                startActivity(i);
                break;
            case R.id.B_to:
                i.putExtra("value","Bank");
                startActivity(i);
                break;
            case R.id.B_search:
                EditText Search =  findViewById(R.id.Search_Box);
                String SearchValue = Search.getText().toString();
                if(SearchValue.equals("")){
                    Toast.makeText(Main2Activity.this, "Please enter some valid text in search box", Toast.LENGTH_SHORT).show();
                }else {
                    i.putExtra("value","Search");
                    i.putExtra("Search",SearchValue);
                    startActivity(i);
                    break;

                }
        }
    }

}
